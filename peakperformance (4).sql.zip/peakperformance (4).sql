-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Sep 01, 2024 at 02:41 AM
-- Server version: 8.0.35
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peakperformance`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `BookingID` int NOT NULL,
  `FacilityID` int NOT NULL,
  `BookingDate` date NOT NULL,
  `TimeDurationID` int NOT NULL,
  `UserID` int NOT NULL,
  `Notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`BookingID`, `FacilityID`, `BookingDate`, `TimeDurationID`, `UserID`, `Notes`) VALUES
(3, 1, '2024-08-25', 2, 1, 'Test'),
(4, 9, '2024-09-07', 3, 1, ''),
(5, 4, '2024-08-25', 4, 1, 'test'),
(6, 7, '2024-09-06', 5, 1, 'Test'),
(7, 11, '2024-09-07', 6, 1, 'Clay '),
(8, 5, '2024-08-29', 7, 1, 'Te'),
(9, 8, '2024-08-31', 8, 1, 'Test'),
(10, 10, '2024-08-31', 9, 1, 'Test'),
(11, 10, '2024-08-31', 10, 1, ''),
(13, 1, '2024-08-29', 3, 1, ''),
(14, 1, '2024-08-29', 2, 1, ''),
(15, 1, '2024-08-29', 4, 1, ''),
(16, 1, '2024-08-29', 5, 1, ''),
(17, 1, '2024-08-29', 6, 1, ''),
(18, 1, '2024-08-29', 7, 1, ''),
(19, 1, '2024-08-29', 8, 1, ''),
(20, 1, '2024-08-29', 9, 1, ''),
(21, 1, '2024-08-29', 10, 1, ''),
(22, 4, '2024-08-29', 1, 1, ''),
(23, 4, '2024-08-29', 2, 1, ''),
(24, 4, '2024-08-29', 3, 1, ''),
(25, 1, '2024-09-08', 1, 1, ''),
(26, 1, '2024-09-08', 10, 1, ''),
(27, 1, '2024-09-08', 9, 1, ''),
(28, 1, '2024-09-08', 2, 1, ''),
(29, 1, '2024-09-08', 3, 2, ''),
(30, 1, '2024-09-07', 1, 2, ''),
(31, 1, '2024-09-08', 4, 2, ''),
(32, 7, '2024-08-29', 1, 1, ''),
(33, 7, '2024-08-29', 2, 1, ''),
(34, 8, '2024-08-29', 1, 1, ''),
(35, 7, '2024-08-29', 3, 1, 'Test 1 2 3'),
(36, 7, '2024-08-29', 4, 1, 'Test 12345'),
(37, 7, '2024-12-28', 1, 1, 'DESEMBER'),
(38, 10, '2024-08-31', 1, 1, 'Test'),
(39, 7, '2024-09-02', 1, 1, 'fs');

-- --------------------------------------------------------

--
-- Table structure for table `EventCategories`
--

CREATE TABLE `EventCategories` (
  `CategoryID` int NOT NULL,
  `CategoryName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `EventCategories`
--

INSERT INTO `EventCategories` (`CategoryID`, `CategoryName`) VALUES
(1, 'Tennis'),
(2, 'Lawn Bowl'),
(3, 'Function');

-- --------------------------------------------------------

--
-- Table structure for table `EventRegistrations`
--

CREATE TABLE `EventRegistrations` (
  `RegistrationID` int NOT NULL,
  `EventID` int NOT NULL,
  `UserID` int NOT NULL,
  `RegistrationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `EventRegistrations`
--

INSERT INTO `EventRegistrations` (`RegistrationID`, `EventID`, `UserID`, `RegistrationDate`) VALUES
(50, 3, 1, '2024-08-31'),
(52, 4, 1, '2024-08-31'),
(53, 5, 1, '2024-08-31'),
(54, 6, 1, '2024-08-31'),
(55, 7, 1, '2024-08-31'),
(56, 8, 1, '2024-08-31');

-- --------------------------------------------------------

--
-- Table structure for table `Events`
--

CREATE TABLE `Events` (
  `EventID` int NOT NULL,
  `EventName` varchar(255) NOT NULL,
  `EventDate` date NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `Location` varchar(255) NOT NULL,
  `CategoryID` int NOT NULL,
  `Description` text,
  `EventStatus` enum('Scheduled','Ongoing','Completed','Cancelled') NOT NULL,
  `ImageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Events`
--

INSERT INTO `Events` (`EventID`, `EventName`, `EventDate`, `StartTime`, `EndTime`, `Location`, `CategoryID`, `Description`, `EventStatus`, `ImageURL`) VALUES
(1, 'Bonfire Winter Night', '2024-11-01', '18:00:00', '23:00:00', 'Club Grounds', 3, 'Enjoy live music, food, and fun at our Bonfire Winter Night.', 'Scheduled', 'img/function-event-1.png'),
(2, 'Wine Tasting', '2024-09-03', '19:00:00', '22:00:00', 'Clubhouse', 3, 'Join us for a delightful Wine Tasting event at 7 PM.', 'Scheduled', 'img/function-event-2.png'),
(3, 'Tennis Workshop', '2024-09-05', '10:00:00', '12:00:00', 'Tennis Court 1', 1, 'Join our free Tennis Workshop and enhance your skills.', 'Scheduled', 'img/tennis-event-2.png'),
(4, 'Tennis Tournament', '2024-09-08', '09:00:00', '17:00:00', 'Tennis Courts', 1, 'Buy tickets online for our exciting Tennis Tournament.', 'Scheduled', 'img/tennis-event-1.png'),
(5, 'Lawn Bowling Tournament', '2024-09-10', '10:00:00', '14:00:00', 'Lawn Bowling Green', 2, 'Let\'s cheer for our team at the Lawn Bowling Tournament!', 'Scheduled', 'img/bowl-event-1.png'),
(6, 'Wine Tasting', '2024-09-15', '18:00:00', '21:00:00', 'Clubhouse', 3, 'Explore refined wines in an engrossing journey. Join now!', 'Scheduled', 'img/function-event-3.png'),
(7, 'Tennis Match', '2024-09-18', '09:00:00', '13:00:00', 'Tennis Court 2', 1, 'Get ready for the most thrilling tennis event of the year!', 'Scheduled', 'img/tennis-event-3.png'),
(8, 'Bowling Night', '2024-09-25', '20:00:00', '23:00:00', 'Lawn Bowling Green', 2, 'Join us for an exciting Bowling Night at 8:00 PM!', 'Scheduled', 'img/bowl-event-2.png');

-- --------------------------------------------------------

--
-- Table structure for table `Facilities`
--

CREATE TABLE `Facilities` (
  `FacilityID` int NOT NULL,
  `FacilityType` enum('Tennis','Lawn Bowl','Function') NOT NULL,
  `FacilityName` varchar(255) NOT NULL,
  `Image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Facilities`
--

INSERT INTO `Facilities` (`FacilityID`, `FacilityType`, `FacilityName`, `Image`) VALUES
(1, 'Tennis', 'Hard Court 1', 'img/hard-court.png'),
(2, 'Tennis', 'Grass Court 1', 'img/grass-court.png'),
(3, 'Tennis', 'Clay Court 1', 'img/clay-court.png'),
(4, 'Lawn Bowl', 'Green 1', 'img/grass-lawn.png'),
(5, 'Lawn Bowl', 'Green 2', 'img/grass-lawn.png'),
(6, 'Lawn Bowl', 'Green 3', 'img/grass-lawn.png'),
(7, 'Function', 'Banquet Hall', 'img/banquet-hall.png'),
(8, 'Function', 'Conference Room', 'img/conference.png'),
(9, 'Tennis', 'Hard Court 2', 'img/hard-court.png'),
(10, 'Tennis', 'Grass Court 2', 'img/grass-court.png'),
(11, 'Tennis', 'Clay Court 2', 'img/clay-court.png');

-- --------------------------------------------------------

--
-- Table structure for table `Roles`
--

CREATE TABLE `Roles` (
  `RoleID` int NOT NULL,
  `RoleName` enum('Member','Staff') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Roles`
--

INSERT INTO `Roles` (`RoleID`, `RoleName`) VALUES
(1, 'Member'),
(2, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `Subscribers`
--

CREATE TABLE `Subscribers` (
  `SubscriberID` int NOT NULL,
  `Email` varchar(255) NOT NULL,
  `SubscriptionDate` date NOT NULL,
  `StatusID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Subscribers`
--

INSERT INTO `Subscribers` (`SubscriberID`, `Email`, `SubscriptionDate`, `StatusID`) VALUES
(1, 'member1@example.com', '2024-08-22', 1),
(2, '20019895@students.koi.edu.au', '2024-08-27', 1),
(3, 'neilsudharmono@gmail.com', '2024-08-27', 1),
(4, 'wuwu@yopmail.com', '2024-08-27', 1),
(5, 'neilcasaandra1609@gmail.com', '2024-08-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `SubscriptionStatus`
--

CREATE TABLE `SubscriptionStatus` (
  `StatusID` int NOT NULL,
  `StatusName` enum('Active','Unsubscribed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `SubscriptionStatus`
--

INSERT INTO `SubscriptionStatus` (`StatusID`, `StatusName`) VALUES
(1, 'Active'),
(2, 'Unsubscribed');

-- --------------------------------------------------------

--
-- Table structure for table `TimeDurations`
--

CREATE TABLE `TimeDurations` (
  `TimeDurationID` int NOT NULL,
  `TimeDuration` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `TimeDurations`
--

INSERT INTO `TimeDurations` (`TimeDurationID`, `TimeDuration`) VALUES
(1, '08.00 - 09.00'),
(2, '09.00 - 10.00'),
(3, '10.00 - 11.00'),
(4, '11.00 - 12.00'),
(5, '12.00 - 13.00'),
(6, '13.00 - 14.00'),
(7, '14.00 - 15.00'),
(8, '15.00 - 16.00'),
(9, '16.00 - 17.00'),
(10, '17.00 - 18.00');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `UserID` int NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL,
  `RoleID` int NOT NULL,
  `PasswordHash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`, `RoleID`, `PasswordHash`) VALUES
(1, 'Neil', 'Member', 'member1@example.com', '1234567890', 1, '$2y$10$bugHwPeYz1ISDtis04QE6ObhXo1O8SDZWaQ.wbsx.hQHwQue1BLZe'),
(2, 'Neil', 'Staff', 'staff1@example.com', '1234567893', 2, '$2y$10$bugHwPeYz1ISDtis04QE6ObhXo1O8SDZWaQ.wbsx.hQHwQue1BLZe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `FacilityID` (`FacilityID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `EventCategories`
--
ALTER TABLE `EventCategories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  ADD PRIMARY KEY (`RegistrationID`),
  ADD KEY `EventID` (`EventID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `Events`
--
ALTER TABLE `Events`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- Indexes for table `Facilities`
--
ALTER TABLE `Facilities`
  ADD PRIMARY KEY (`FacilityID`);

--
-- Indexes for table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `Subscribers`
--
ALTER TABLE `Subscribers`
  ADD PRIMARY KEY (`SubscriberID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `StatusID` (`StatusID`);

--
-- Indexes for table `SubscriptionStatus`
--
ALTER TABLE `SubscriptionStatus`
  ADD PRIMARY KEY (`StatusID`);

--
-- Indexes for table `TimeDurations`
--
ALTER TABLE `TimeDurations`
  ADD PRIMARY KEY (`TimeDurationID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `RoleID` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `EventCategories`
--
ALTER TABLE `EventCategories`
  MODIFY `CategoryID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  MODIFY `RegistrationID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `Events`
--
ALTER TABLE `Events`
  MODIFY `EventID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `Facilities`
--
ALTER TABLE `Facilities`
  MODIFY `FacilityID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `Roles`
--
ALTER TABLE `Roles`
  MODIFY `RoleID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Subscribers`
--
ALTER TABLE `Subscribers`
  MODIFY `SubscriberID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `SubscriptionStatus`
--
ALTER TABLE `SubscriptionStatus`
  MODIFY `StatusID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `TimeDurations`
--
ALTER TABLE `TimeDurations`
  MODIFY `TimeDurationID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`FacilityID`) REFERENCES `Facilities` (`FacilityID`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

--
-- Constraints for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  ADD CONSTRAINT `eventregistrations_ibfk_1` FOREIGN KEY (`EventID`) REFERENCES `Events` (`EventID`),
  ADD CONSTRAINT `eventregistrations_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

--
-- Constraints for table `Events`
--
ALTER TABLE `Events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `EventCategories` (`CategoryID`);

--
-- Constraints for table `Subscribers`
--
ALTER TABLE `Subscribers`
  ADD CONSTRAINT `subscribers_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `SubscriptionStatus` (`StatusID`);

--
-- Constraints for table `Users`
--
ALTER TABLE `Users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `Roles` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
