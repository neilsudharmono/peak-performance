-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Aug 28, 2024 at 11:15 AM
-- Server version: 8.0.35
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peakperformance`
--

-- --------------------------------------------------------

--
-- Table structure for table `Bookings`
--

CREATE TABLE `Bookings` (
  `BookingID` int NOT NULL,
  `FacilityID` int NOT NULL,
  `UserID` int NOT NULL,
  `Firstname` varchar(40) NOT NULL,
  `Lastname` varchar(40) NOT NULL,
  `Email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `BookingDate` date NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `Notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Bookings`
--

INSERT INTO `Bookings` (`BookingID`, `FacilityID`, `UserID`, `Firstname`, `Lastname`, `Email`, `Phone`, `BookingDate`, `StartTime`, `EndTime`, `Notes`) VALUES
(2, 1, 1, '2', 'Test', '20019895@students.koi.edu.au', '0411111111', '2024-08-25', '07:06:00', '10:06:00', 'Test'),
(3, 1, 1, '3', 'Test', '20019895@students.koi.edu.au', '0411111111', '2024-08-25', '07:06:00', '10:06:00', 'Test'),
(4, 9, 1, 'Test', 'test 4', 'neilcasaandra1609@gmail.com', '0411111111', '2024-09-07', '10:00:00', '12:00:00', ''),
(5, 4, 1, 'Test', 'test lawn', 'wuwu@yopmail.com', '0411111111', '2024-08-25', '19:29:00', '22:29:00', 'test'),
(6, 7, 1, 'Test funct', 'Test', 'neilsudharmono@gmail.com', '0488888888', '2024-09-06', '11:30:00', '12:30:00', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `EventCategories`
--

CREATE TABLE `EventCategories` (
  `CategoryID` int NOT NULL,
  `CategoryName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `EventCategories`
--

INSERT INTO `EventCategories` (`CategoryID`, `CategoryName`) VALUES
(1, 'Tennis'),
(2, 'Lawn Bowl'),
(3, 'Function');

-- --------------------------------------------------------

--
-- Table structure for table `EventRegistrations`
--

CREATE TABLE `EventRegistrations` (
  `RegistrationID` int NOT NULL,
  `EventID` int NOT NULL,
  `UserID` int NOT NULL,
  `RegistrationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Events`
--

CREATE TABLE `Events` (
  `EventID` int NOT NULL,
  `EventName` varchar(255) NOT NULL,
  `EventDate` date NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `Location` varchar(255) NOT NULL,
  `CategoryID` int NOT NULL,
  `Description` text,
  `EventStatus` enum('Scheduled','Ongoing','Completed','Cancelled') NOT NULL,
  `ImageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Events`
--

INSERT INTO `Events` (`EventID`, `EventName`, `EventDate`, `StartTime`, `EndTime`, `Location`, `CategoryID`, `Description`, `EventStatus`, `ImageURL`) VALUES
(1, 'Bonfire Winter Night', '2024-09-01', '18:00:00', '23:00:00', 'Club Grounds', 3, 'Enjoy live music, food, and fun at our Bonfire Winter Night.', 'Scheduled', 'img/function-event-1.png'),
(2, 'Wine Tasting', '2024-09-03', '19:00:00', '22:00:00', 'Clubhouse', 3, 'Join us for a delightful Wine Tasting event at 7 PM.', 'Scheduled', 'img/function-event-2.png'),
(3, 'Tennis Workshop', '2024-09-05', '10:00:00', '12:00:00', 'Tennis Court 1', 1, 'Join our free Tennis Workshop and enhance your skills.', 'Scheduled', 'img/tennis-event-2.png'),
(4, 'Tennis Tournament', '2024-09-08', '09:00:00', '17:00:00', 'Tennis Courts', 1, 'Buy tickets online for our exciting Tennis Tournament.', 'Scheduled', 'img/tennis-event-1.png'),
(5, 'Lawn Bowling Tournament', '2024-09-10', '10:00:00', '14:00:00', 'Lawn Bowling Green', 2, 'Let\'s cheer for our team at the Lawn Bowling Tournament!', 'Scheduled', 'img/bowl-event-1.png'),
(6, 'Wine Tasting', '2024-09-15', '18:00:00', '21:00:00', 'Clubhouse', 3, 'Explore refined wines in an engrossing journey. Join now!', 'Scheduled', 'img/function-event-3.png'),
(7, 'Tennis Match', '2024-09-18', '09:00:00', '13:00:00', 'Tennis Court 2', 1, 'Get ready for the most thrilling tennis event of the year!', 'Scheduled', 'img/tennis-event-3.png'),
(8, 'Bowling Night', '2024-09-25', '20:00:00', '23:00:00', 'Lawn Bowling Green', 2, 'Join us for an exciting Bowling Night at 8:00 PM!', 'Scheduled', 'img/bowl-event-2.png');

-- --------------------------------------------------------

--
-- Table structure for table `Facilities`
--

CREATE TABLE `Facilities` (
  `FacilityID` int NOT NULL,
  `FacilityType` enum('Tennis','Lawn Bowl','Function') NOT NULL,
  `FacilityName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Facilities`
--

INSERT INTO `Facilities` (`FacilityID`, `FacilityType`, `FacilityName`) VALUES
(1, 'Tennis', 'Hard Court 1'),
(2, 'Tennis', 'Grass Court 1'),
(3, 'Tennis', 'Clay Court 1'),
(4, 'Lawn Bowl', 'Green 1'),
(5, 'Lawn Bowl', 'Green 2'),
(6, 'Lawn Bowl', 'Green 3'),
(7, 'Function', 'Banquet Hall'),
(8, 'Function', 'Conference Room'),
(9, 'Tennis', 'Hard Court 2'),
(10, 'Tennis', 'Grass Court 2'),
(11, 'Tennis', 'Clay Court 2');

-- --------------------------------------------------------

--
-- Table structure for table `Roles`
--

CREATE TABLE `Roles` (
  `RoleID` int NOT NULL,
  `RoleName` enum('Member','Staff') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Roles`
--

INSERT INTO `Roles` (`RoleID`, `RoleName`) VALUES
(1, 'Member'),
(2, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `Subscribers`
--

CREATE TABLE `Subscribers` (
  `SubscriberID` int NOT NULL,
  `Email` varchar(255) NOT NULL,
  `SubscriptionDate` date NOT NULL,
  `StatusID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Subscribers`
--

INSERT INTO `Subscribers` (`SubscriberID`, `Email`, `SubscriptionDate`, `StatusID`) VALUES
(1, 'member1@example.com', '2024-08-22', 1),
(2, '20019895@students.koi.edu.au', '2024-08-27', 1),
(3, 'neilsudharmono@gmail.com', '2024-08-27', 1),
(4, 'wuwu@yopmail.com', '2024-08-27', 1),
(5, 'neilcasaandra1609@gmail.com', '2024-08-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `SubscriptionStatus`
--

CREATE TABLE `SubscriptionStatus` (
  `StatusID` int NOT NULL,
  `StatusName` enum('Active','Unsubscribed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `SubscriptionStatus`
--

INSERT INTO `SubscriptionStatus` (`StatusID`, `StatusName`) VALUES
(1, 'Active'),
(2, 'Unsubscribed');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `UserID` int NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL,
  `RoleID` int NOT NULL,
  `PasswordHash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`, `RoleID`, `PasswordHash`) VALUES
(1, 'Neil', 'Member', 'member1@example.com', '1234567890', 1, '$2y$10$bugHwPeYz1ISDtis04QE6ObhXo1O8SDZWaQ.wbsx.hQHwQue1BLZe'),
(2, 'Neil', 'Staff', 'staff1@example.com', '1234567893', 2, '$2y$10$bugHwPeYz1ISDtis04QE6ObhXo1O8SDZWaQ.wbsx.hQHwQue1BLZe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Bookings`
--
ALTER TABLE `Bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `FacilityID` (`FacilityID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `EventCategories`
--
ALTER TABLE `EventCategories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  ADD PRIMARY KEY (`RegistrationID`),
  ADD KEY `EventID` (`EventID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `Events`
--
ALTER TABLE `Events`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- Indexes for table `Facilities`
--
ALTER TABLE `Facilities`
  ADD PRIMARY KEY (`FacilityID`);

--
-- Indexes for table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `Subscribers`
--
ALTER TABLE `Subscribers`
  ADD PRIMARY KEY (`SubscriberID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `StatusID` (`StatusID`);

--
-- Indexes for table `SubscriptionStatus`
--
ALTER TABLE `SubscriptionStatus`
  ADD PRIMARY KEY (`StatusID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `RoleID` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Bookings`
--
ALTER TABLE `Bookings`
  MODIFY `BookingID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `EventCategories`
--
ALTER TABLE `EventCategories`
  MODIFY `CategoryID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  MODIFY `RegistrationID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Events`
--
ALTER TABLE `Events`
  MODIFY `EventID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `Facilities`
--
ALTER TABLE `Facilities`
  MODIFY `FacilityID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `Roles`
--
ALTER TABLE `Roles`
  MODIFY `RoleID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Subscribers`
--
ALTER TABLE `Subscribers`
  MODIFY `SubscriberID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `SubscriptionStatus`
--
ALTER TABLE `SubscriptionStatus`
  MODIFY `StatusID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Bookings`
--
ALTER TABLE `Bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`FacilityID`) REFERENCES `Facilities` (`FacilityID`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

--
-- Constraints for table `EventRegistrations`
--
ALTER TABLE `EventRegistrations`
  ADD CONSTRAINT `eventregistrations_ibfk_1` FOREIGN KEY (`EventID`) REFERENCES `Events` (`EventID`),
  ADD CONSTRAINT `eventregistrations_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

--
-- Constraints for table `Events`
--
ALTER TABLE `Events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `EventCategories` (`CategoryID`);

--
-- Constraints for table `Subscribers`
--
ALTER TABLE `Subscribers`
  ADD CONSTRAINT `subscribers_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `SubscriptionStatus` (`StatusID`);

--
-- Constraints for table `Users`
--
ALTER TABLE `Users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `Roles` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
